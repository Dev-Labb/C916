CREATE TABLE Client_A_Contacts 
(
    First_Name  varchar (100),
    Last_Name varchar (100),
    City varchar (50),
    County varchar (50),
    Zip varchar (20),
    OfficePhone varchar (15),
    MobilePone varchar (15), 
)